#include<iostream>
#include<vector>
#include<set>
#include<unordered_set>
#include<fstream>
#include <time.h>
#include <algorithm>
#include"lab_7.h"
using namespace std;

int main(){
	
	vector<string> myvec;
	vector<string> mydata;
	vector<string>::iterator itr;
	set<string> myset;
	unordered_set<string> myhash;
	File_read(myvec, "words.txt");
	
	for(unsigned n = 500; n<=5000; n = n + 500){
		string str = insert_time(myvec, n, myset, myhash);
		cout<<str<<endl;
		mydata.push_back(str);
	}

	ofstream os("data.txt");  
	itr = mydata.begin();
	while(itr!=mydata.end())
	{
		if (!os) { std::cerr<<"Error writing to ..."<<std::endl; } else {  
	  		os << (*itr);
			itr++;  
		} 
	} 
	return 0; 

  	//random_shuffle ( myvector.begin(), myvector.end() );
 

}
