#include<iostream>
#include<vector>
#include<set>
#include<fstream>
#include <algorithm>
#include<time.h>
using namespace std;

void File_read( vector<string>& myvec, const string listFile ){

	const char *cstr = listFile.c_str();
	ifstream myfile (cstr);

	string line;

	if (myfile.is_open()){ 
   		while (getline(myfile,line)) 
		{
			myvec.push_back(line);
		}
	     myfile.close();
	}
}

template<typename T,typename V>
string insert_time(vector<string>& myvec, unsigned n, T& t, V& v){
	string result;
	if(myvec.size()<n){
		cout<<"error !, vector not large enough"<<endl;
	}
	else{
		
		typename T::iterator itr_1;
		typename V::iterator itr_2;
		clock_t start, finish;
   		double duration_insert_T = 0;
		double duration_find_T = 0;
		double duration_insert_V = 0;
		double duration_find_V = 0;
		double temp = 0;
		for(unsigned j=0;j<10;j++)
		{   		
			
			t.clear();
			random_shuffle ( myvec.begin(), myvec.end() );

			start = clock();
			for(unsigned i=0;i<n;i++){
				t.insert(myvec[i]);	
			}

			finish = clock();
			temp = (double)(finish - start)*1000000/CLOCKS_PER_SEC;
			temp = temp/(double)n;
			//cout<<temp<<" ";
			duration_insert_T = duration_insert_T + temp;
			
			start = clock();
			for(unsigned i=0;i<n;i++){
				itr_1 = t.find(myvec[i]);	
			}
			finish = clock();
			temp = (double)(finish - start)*1000000/CLOCKS_PER_SEC;
			temp = temp/(double)n;
			//cout<<temp<<" ";
			duration_find_T = duration_find_T + temp;

			start = clock();
			for(unsigned i=0;i<n;i++){
				v.insert(myvec[i]);	
			}

			finish = clock();
			temp = (double)(finish - start)*1000000/CLOCKS_PER_SEC;
			temp = temp/(double)n;
			//cout<<temp<<" ";
			duration_insert_V = duration_insert_V + temp;
			
			start = clock();
			for(unsigned i=0;i<n;i++){
				itr_2 = v.find(myvec[i]);	
			}
			finish = clock();
			temp = (double)(finish - start)*1000000/CLOCKS_PER_SEC;
			temp = temp/(double)n;
			//cout<<temp<<endl;
			duration_find_V = duration_find_V + temp;

			
			
		}
		//cout<<duration_insert_T<<" "<<duration_find_T<<" "<<duration_insert_V<<" "<<duration_find_V<<endl;
		duration_insert_T = duration_insert_T/10; duration_find_T = duration_find_T/10;
		duration_insert_V = duration_insert_V/10; duration_find_V = duration_find_V/10;
		result = (to_string(n) + " " + to_string(duration_insert_T) + " " + to_string(duration_insert_V) + " " + to_string(duration_find_T) + " " + to_string(duration_find_V) + "\n");
				
	}
	cout<<endl;
	return result;
}	
