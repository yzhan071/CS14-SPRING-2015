//Student Name: Yunjian Zhang
//Student Number: 861142074
#include<iostream>
#include<list>
#include<vector>
#include<utility>
#include<set>
#include<map>
#include "sort.h"
using namespace std;
typedef list<pair<int,int>> container_1;
typedef list<int> container_2;

int main()
{
    container_2 mylist_int;
    mylist_int.push_back(2);
    mylist_int.push_back(4);
    mylist_int.push_back(5);
    mylist_int.push_back(1);
    mylist_int.push_back(8);
    mylist_int.push_back(9);
    
    cout<<"pre:  ";
    for(container_2::iterator itr = mylist_int.begin();itr!=mylist_int.end();itr++){
        cout<<*itr<<" ";
    }
    cout<<endl;
    
    selectionsort(mylist_int); // (10,2) (-3,-1) (-8,0) (1,1) (1,1) (0,0) (10,2) (5,5) (5,-5) (0,0) (10,2)
    
    cout<<"post: ";
    for(container_2::iterator itr = mylist_int.begin();itr!=mylist_int.end();itr++){
        cout<<*itr<<" ";
    } 
    cout<<endl;
    
    container_1 mylist;
    mylist.push_back(make_pair(1,2));
    mylist.push_back(make_pair(3,-1));
    mylist.push_back(make_pair(-1,3));
    mylist.push_back(make_pair(0,0));
    mylist.push_back(make_pair(2,3));
    mylist.push_back(make_pair(1,2));
    mylist.push_back(make_pair(1,-2));
    mylist.push_back(make_pair(8,10));
    
    cout<<"pre:  ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    }
    cout<<endl;
    
    selectionsort(mylist); // (10,2) (-3,-1) (-8,0) (1,1) (1,1) (0,0) (10,2) (5,5) (5,-5) (0,0) (10,2)
    
    cout<<"post: ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    } 
    cout<<endl;
    
    mylist.clear();
    
    mylist.push_back(make_pair(10,2));
    mylist.push_back(make_pair(-3,-1));
    mylist.push_back(make_pair(-8,0));
    mylist.push_back(make_pair(1,1));
    mylist.push_back(make_pair(1,1));
    mylist.push_back(make_pair(0,0));
    mylist.push_back(make_pair(10,2));
    mylist.push_back(make_pair(5,5));
    mylist.push_back(make_pair(5,-5));
    mylist.push_back(make_pair(0,0));
    mylist.push_back(make_pair(10,2));
    
    cout<<"pre:  ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    }
    cout<<endl;
    selectionsort(mylist); // (10,2) (-3,-1) (-8,0) (1,1) (1,1) (0,0) (10,2) (5,5) (5,-5) (0,0) (10,2)
    
    cout<<"post: ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    } 
    cout<<endl;
    
    mylist.clear();
    
    mylist.push_back(make_pair(-1,3));
    mylist.push_back(make_pair(0,0));
    mylist.push_back(make_pair(1,-2));
    mylist.push_back(make_pair(1,2));
    mylist.push_back(make_pair(1,2));
    mylist.push_back(make_pair(2,3));
    mylist.push_back(make_pair(3,-1));
    mylist.push_back(make_pair(8,10));
    
    cout<<"pre:  ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    }
    cout<<endl;
    selectionsort(mylist); // (-1,3) (0,0) (1,-2) (1,2) (1,2) (2,3) (3,-1) (8,10)
    
    cout<<"post: ";
    for(container_1::iterator itr = mylist.begin();itr!=mylist.end();itr++){
        cout<<"("<<itr->first<<","<<itr->second<<") ";
    } 
    cout<<endl;
    
}