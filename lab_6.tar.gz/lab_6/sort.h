#include<iostream>
using namespace std;

template<typename L>
void selectionsort(L& l){
  if(l.size()!=0){
    int move_count = 0;
    typename L::iterator itr_temp;
    typename L::iterator itr_move_1;
    typename L::iterator itr_move_2;
    typename L::iterator itr_store;
    typename L::iterator itr_end;
    int i = 0;
    
    for(i = 0; i<l.size()-1; i++){
        
        //for(typename L::iterator it = l.begin();it!=l.end();it++){
          //  cout<<it->first<<it->second<<" ";
        //}
       // cout<<endl;
        
        itr_temp = l.begin();
        itr_store = l.begin();
        itr_move_1 = l.begin();
        itr_end = l.begin();
        
        advance(itr_temp,i+1);
        advance(itr_store,i+1);
        
        advance(itr_move_1,i);
        advance(itr_end,(l.size())-1);

        
        int count = i + 1;
        int record = i + 1;
        itr_move_2 = itr_move_1;
        itr_move_2++;
   
        for(; itr_move_2!=l.end();itr_move_2++){
            
            if(itr_temp==itr_end){
                if((*itr_store)<(*itr_move_1)){
                    move_count = move_count + 3;
                    //cout<<"shit"<<itr_move_1->first<<itr_store->second<<endl;
                    auto temp1 = *itr_move_1;
                    auto temp2 = *itr_store;
                    
                    typename L::iterator itr = itr_move_1; l.erase(itr);
                    
                    itr = l.begin(); advance(itr,record-1);
                    l.erase(itr); 
                    
                    itr = l.begin(); advance(itr,i); l.insert(itr,temp2);
                    itr = l.begin(); advance(itr,record); l.insert(itr,temp1);
                    
                }
                break;
            }
            else{
                    itr_temp++; 
                    count++;
                   
                    if((*itr_temp)<(*itr_store)){
                        
                        itr_store = itr_temp;
                        record = count;
                    }
            } 
        }
    }
    cout<<"0 copy and "<<move_count<<" moves"<<endl;
  }
  
}
