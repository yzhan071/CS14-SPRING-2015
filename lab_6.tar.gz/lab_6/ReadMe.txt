Question2
Part1: 
My selection sort is not stable, and I can use an example to prove it.
Now, assuming that we have an unsorted list: 1 4 2 3 4 1.
Let's focus on 4, and mark the right 4 with a, the left 4 with b.
the original list:		1 4a 2 3 4b 1; 
after the first iteration:	1 4a 2 3 4b 1; swap did not occur
after the second iteration:     1 1 2 3 4b 4a; swap occured
After some iterations without any swap because the list is already sorted, the final result is 1 1 2 3 4b 4a. Now b is in front of a, which prooved that the algorithm is not stable.

Part2:
Testint program using sort.h in Question1. In addition, I add some codes for loop in my selection sort function: 
cout<<"The "<<i+1<<" th iteration"<<" swap "<<temp1<<" with "<<temp2<<endl;

#include<iostream>
#include<list>
#include<vector>
#include<utility>
#include<set>
#include<map>
#include "sort.h"
using namespace std;
typedef list<pair<int,int>> container_1;
typedef list<int> container_2;

int main()
{
    container_2 mylist_int;
    mylist_int.push_back(1);
    mylist_int.push_back(4);
    mylist_int.push_back(2);
    mylist_int.push_back(3);
    mylist_int.push_back(4);
    mylist_int.push_back(1);
    
    cout<<"pre:  ";
    for(container_2::iterator itr = mylist_int.begin();itr!=mylist_int.end();itr++){
        cout<<*itr<<" ";
    }
    cout<<endl;
    
    selectionsort(mylist_int); 
    
    cout<<"post: ";
    for(container_2::iterator itr = mylist_int.begin();itr!=mylist_int.end();itr++){
        cout<<*itr<<" ";
    } 
    cout<<endl;
}

the terminal output is:
pre:  1 4 2 3 4 1 
The 2 th iteration swap 4 with 1
0 copy and 3 moves
post: 1 1 2 3 4 4 

This means that during the second iteration, the first 4 changed place with the element at the end of the list, which is 1. This example also prooved that this sorting method is not stable.
