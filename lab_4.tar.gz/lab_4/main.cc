#include<iostream>
#include<queue>
#include <sstream>
#include"lab4.h"
using namespace std;

int main( int argc, char* argv[] ){
    
        std::istringstream iss( argv[1] );
        int val;

        if (iss >> val)
        {
            cout<<"The input upper bound is "<<val<<endl;
            
            cout<<"Now print the tree in preorder"<<endl;
            preorder(val);
            cout<<endl;
            
            cout<<"Now print the tree in postorder"<<endl;
            postorder(val);
            cout<<endl;
            
            cout<<"Now print the tree in sortedorder"<<endl;
            sorted(val); 
            cout<<endl;
        }
        else{
            cout<<"Input conversion failed, please input one integer as the only argument"<<endl;
        }
    return 0;
    
}
