#include<iostream>
#include<utility>
using namespace std;

class myelement{
    public:
        int sum;
        pair<int,int> foo;
    
    public:
        myelement(){}
    
        myelement(int start, int m, int n){
            sum = start - m - n;
            get<0>(foo) = m;
            get<1>(foo) = n;
        }
        ~myelement(){};
        
        int getfoo_0() const{
            return get<0>(foo);
        }
        
        int getfoo_1() const{
            return get<1>(foo);
        }
        
        bool operator<(const myelement& rhs) const 
            {
                return sum < rhs.sum;  
            }
};

void preorder_tri(int m, int n, int k){

    if(m+n<k){
    
        cout<<m<<" "<<n<<endl;
        
        preorder_tri(2*m-n,m,k);
        
        preorder_tri(2*m+n,m,k);
        
        preorder_tri(m+2*n,n,k);
   
    }
}

void postorder_tri(int m, int n, int k){

    if(m+n<k){
    
        postorder_tri(2*m-n,m,k);
        
        postorder_tri(2*m+n,m,k);
        
        postorder_tri(m+2*n,n,k);
        
        cout<<m<<" "<<n<<endl;
   
    }
}

void preorder(int k){
    preorder_tri(2,1,k);
    preorder_tri(3,1,k);
}

void postorder(int k){
    postorder_tri(2,1,k);
    postorder_tri(3,1,k);
}


void sorted_tri(int m, int n, int k, priority_queue<myelement>& myqp){
    
    if(m+n<k){
    
        myqp.push(myelement(3,m,n));
        
        sorted_tri(2*m-n,m,k,myqp);
        
        sorted_tri(2*m+n,m,k,myqp);
        
        sorted_tri(m+2*n,n,k,myqp);
   
    }
}


void sorted(int k){
    static priority_queue<myelement> myqp;
    sorted_tri(2,1,k,myqp);
    sorted_tri(3,1,k,myqp);
    
    while(!myqp.empty()){
        cout<<(myqp.top()).getfoo_0()<<" "<<(myqp.top()).getfoo_1()<<endl;
        myqp.pop();
    }
}