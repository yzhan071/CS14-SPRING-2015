#include <iostream>
#include <string>
#include "lab2.h"


using namespace std;

int primecount(forward_list<int> input);

int main() {
    
    
    cout<<"Student name: Yunjian Zhang"<<endl;
    cout<<"SID: 861142074"<<endl<<endl;
    
    string str1 = "pork";
    string str2 = "beef";
    string str3 = "corn";
    string str4 = "banana";
    string str5 = "apple";
    List<string> mylist(str1);
    mylist.push_back(str2);
    mylist.push_back(str3);
    
    
    forward_list<int> my_f_list1(2);
    my_f_list1.push_back(2);
    my_f_list1.push_back(1);
    my_f_list1.push_back(3);
    my_f_list1.push_back(4);
    
    forward_list<string> my_f_list2(str1);
    my_f_list2.push_back(str2);
    my_f_list2.push_back(str3);
    my_f_list2.push_back(str4);
    
    forward_list<string> my_f_list3(str1);
    
    forward_list<int> my_f_list(1);
    for(int i=2;i<=31;i++){
        my_f_list.push_back(i);
    }
    
    cout<<"Part1, the numbers in my_f_list are"<<endl;
    for(int i=1;i<=my_f_list.Size;i++){
        cout<<my_f_list.getObject(i)<<" ";
    }
    cout<<endl;
    cout<<"the prime numbers in the forward_list are"<<endl;
    cout<<"there are "<<primecount(my_f_list)<<" prime_numbers"<<endl<<endl;
    
    cout<<"Part2, the content of my_f_list2 is"<<endl;
    for(int i=1;i<=mylist.Size;i++){
        cout<<mylist.getObject(i)<<" ";
    }
    cout<<endl;
    
    cout<<"the result of function elementSwap is"<<endl;
    mylist.elementSwap(1);
    for(int i=1;i<=mylist.Size;i++){
        cout<<mylist.getObject(i)<<" ";
    }
    cout<<endl<<endl;
    
   
   cout<<"Part3, the content of my_f_list2 is"<<endl;
    for(int i=1;i<=my_f_list2.Size;i++){
        cout<<my_f_list2.getObject(i)<<" ";
    }
    cout<<endl;
    cout<<"The content of my_f_list3 is"<<endl;
    for(int i=1;i<=my_f_list3.Size;i++){
        cout<<my_f_list2.getObject(i)<<" ";
    }
    cout<<endl;
    
    my_f_list3.listCopy(my_f_list2, my_f_list3);
    cout<<"The result of function listCopy is ( Copy my_f_list2 to my_f_list3 )"<<endl;
    for(int i=1;i<=my_f_list3.Size;i++){
        cout<<my_f_list2.getObject(i)<<" ";
    }
    cout<<endl<<endl;
    
    
    
    cout<<"Part4,the content of my_f_list1 is 2, 2, 1, 3, 4"<<endl;
    cout<<"the content of my_f_list2 is"<<endl;
    for(int i=1;i<=4;i++){
        cout<<my_f_list2.getObject(i)<<" ";
    }
    cout<<endl;
    cout<<"the result of printLots function is"<<endl;
    my_f_list2.printLots(my_f_list2,my_f_list1);
    cout<<endl;
    
    
    return 0;
    
}
