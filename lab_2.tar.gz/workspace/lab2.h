#ifndef LIST
#define LIST

#include<iostream>
using namespace std;



template<class Object>
class Node
{
    public:
        Object data;
        Node<Object> *next;
        Node<Object>(const Object& d):data(d),next(NULL){}
};

template<class Object>
class List{
    public:
        int Size;
        Node<Object> * head;
        List(Object objects);
        List(const List<Object>& lst);
        virtual ~List();
        void push_back(Object objects);
        Object getObject(int i);
        List<Object> elementSwap(int pos);
        //List<Object>& operator=(const List<Object> str);
        
};


bool isPrime(int num);
 
template<class Object>
List<Object>::List(Object objects){
    head = new Node<Object>(objects);

    Size = 1;
}

template<class Object>
List<Object>::List(const List<Object>& lst){
    Node<Object>* temp1 = lst.head;
    head = new Node<Object>(temp1->data);
    Size = 1;
    
    while(temp1->next!=NULL){
        temp1 = temp1->next;
        this->push_back(temp1->data);
    }
}

template<class Object>
List<Object>::~List(){
    Node<Object>* temp1 = head;
    
    do{
        Node<Object>* temp2 = temp1;
        temp1 = temp1->next;
        delete temp2;
    }while(temp1!=NULL);
}

template<class Object>
void List<Object>::push_back(Object objects){
    Node<Object>** temp1 = &(head->next);

    while(*temp1!=NULL){
        temp1 = &((*temp1)->next);
    }
    *temp1 = new Node<Object>(objects);
    
    Size++;
}

template<class Object>
Object List<Object>::getObject(int i){
    Node<Object> *temp = head;
    if(i>Size){
        cout<<"index out of range !, now return the last Object"<<endl;
    }
    else{
        for(int j=1;j<i;j++){
            temp = temp->next;
        }
    }
    return temp->data;
}

template<class Object>
List<Object> List<Object>::elementSwap(int pos){

        //Node<Object>** tempa = &(str.head);
    
    if((pos+1)>Size){
        cout<<"input out of range!!"<<endl;
    }
    else if(pos ==1){
        Node<Object>* temp1 = head;//*temp1:addr of 1st node
        Node<Object>* temp2 = head->next; //*temp2:addr of 2nd node
        //Node<Object>** temp3 = &(str.head); 
        
        
       Node<Object>* temp3 = (temp1->next); //*temp3:addr of 2nd node
        temp1->next = temp2->next; //*temp1
        temp2->next = head; //addr
        head = temp3;
    }
    else{
       
        Node<Object>* temp1 = head;
        Node<Object>* temp2 = head;
        Node<Object>* temp3 = head;
        Node<Object>* tempa = head;
        
        for(int j=1;j<pos;j++){
            tempa = temp1;
            temp1 = temp1->next;
            temp2 = temp1->next;
        }
        
        temp3 = temp1->next;
        temp1->next = temp2->next;
        temp2->next = tempa->next;
        tempa->next = temp3;
        
    } 
    return *this; 
}



template<class Object>
class forward_list{
    public:
        int Size;
        Node<Object> * head;
        forward_list(Object objects);
        forward_list(const forward_list<Object>& lst);
        virtual ~forward_list();
        void push_back(Object objects);
        Object getObject(int i);
        void printLots(forward_list<Object> L, forward_list<int> P);
        void listCopy(forward_list<Object> L, forward_list<Object>& P);

        
};

 
template<class Object>
forward_list<Object>::forward_list(Object objects){
    head = new Node<Object>(objects);

    Size = 1;
}

template<class Object>
forward_list<Object>::forward_list(const forward_list<Object>& lst){
    Node<Object>* temp1 = lst.head;
    head = new Node<Object>(temp1->data);
    Size = 1;
    
    while(temp1->next!=NULL){
        temp1 = temp1->next;
        this->push_back(temp1->data);
    }
}

template<class Object>
forward_list<Object>::~forward_list(){
    Node<Object>* temp1 = head;
    
    do{
        Node<Object>* temp2 = temp1;
        temp1 = temp1->next;
        delete temp2;
    }while(temp1!=NULL);
}

template<class Object>
void forward_list<Object>::push_back(Object objects){
    Node<Object>** temp1 = &(head->next);

    while(*temp1!=NULL){
        temp1 = &((*temp1)->next);
    }
    *temp1 = new Node<Object>(objects);
    
    Size++;
}

template<class Object>
Object forward_list<Object>::getObject(int i){
    Node<Object> *temp = head;
    if(i>Size){
        cout<<"index out of range !, now return the last Object"<<endl;
    }
    else{
        for(int j=1;j<i;j++){
            temp = temp->next;
        }
    }
    return temp->data;
}


template<class Object>
void forward_list<Object>::listCopy(forward_list<Object> L, forward_list<Object>& P){
    Node<Object>* temp1 = P.head;
    
    while(temp1!=NULL){
        Node<Object>* temp2 = temp1;
        temp1 = temp1->next;
        delete temp2;
    };
    
    
    Object* object_heap = new Object[L.Size];
    
    Node<Object>* temp3 = L.head;
    
    for(int i = L.Size-1; i>=0; i--){
        object_heap[i] = temp3->data;
        temp3 = temp3->next;
    }
    
    P.head = new Node<Object>(object_heap[0]);
    
    for(int i = 1; i<=L.Size-1; i++){
        P.push_back(object_heap[i]);
    }
    
    delete [] object_heap;
    object_heap = NULL;
    
    P.Size = L.Size;
    
} 

template<class Object>
void forward_list<Object>::printLots(forward_list<Object> L, forward_list<int> P){
    Node<int>* temp1 = P.head;
    while(temp1!=NULL){
        int index = temp1->data;
        Node<Object>* temp2 = L.head;
        
        for(int j=1;j<index;j++){
            
            if(j>=(L.Size))
            { cout<<"index out of range"<<endl;
                break; }
                
          temp2 = temp2->next;
        }
        cout<<temp2->data<<" ";
        
        temp1 = temp1->next;
    }
}

int primecount(forward_list<int> input);


#endif