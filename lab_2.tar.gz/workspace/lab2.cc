#include<math.h>
#include"lab2.h"


bool isPrime(int num)
{
    if( num<=1 )
        return false;
    else if(num == 2)
        return true;
    else if(num % 2 == 0)
        return false;
    else{
        bool prime = true;
        int divisor = 3;
        double num_d = static_cast<double>(num);
        int upperLimit = static_cast<int>(sqrt(num_d)+1);
        
        while(divisor<=upperLimit){
            if(num%divisor==0)
                prime = false;
                divisor += 2;
        }
        return prime;
    }
}


int primecount(forward_list<int> input){
    bool is_p = false;
    if((input.head)->next!=NULL)
    {  
        Node<int>* temp = input.head;
        is_p = isPrime(temp->data);
        if( is_p ){
        //prime_numbers++;
            cout<<temp->data<<" ";
        }
        
        //temp1 = NULL;
        input.head = temp->next;
        Node<int>* temp1 = temp;
        delete temp1;
        
        if(is_p)
         return ( 1 + primecount(input) ); 
        else
         return primecount(input);
         
    }
    else{
        if( isPrime(input.head->data) ){
        //prime_numbers++;
            cout<<input.head->data<<endl;
            return 1;
        }
        else return 0;
    }
    
}


