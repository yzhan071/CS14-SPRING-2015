#include<iostream>
#include<map>
#include "bst.h"

using namespace std;

int main(){
    std::cout << "Student name: yunjian zhang" << std::endl;
    cout<<"SID: 861142074"<<endl;
    cout<<"uploaded in May 10, 2015"<<endl;
    
    BST<int> mytree;
    
    cout<<"now insert value from 1 to 5 in sorted order"<<endl;
        
    mytree.insert(10);
    mytree.insert(20);
    mytree.insert(40);
    mytree.insert(50);
    mytree.insert(60);
    mytree.insert(70);
    mytree.insert(35);
    mytree.insert(45);
        
    
    
    cout<<"print my tree in pre-order"<<endl;
    mytree.preorder();
    cout<<endl;
    
    cout<<"print my tree in post-order"<<endl;
    mytree.postorder();
    cout<<endl;
    
    cout<<"print my tree in in-order"<<endl;
    mytree.inorder();
    cout<<endl;
    
    cout<<"now find the minCover of this tree and print the nodes"<<endl;
    mytree.minCover();
    
    int buffer[100];
    for(int i=0;i<100;i++){
        buffer[i] = 0;
    }
    
    cout<<"now print the path whose sum equals to 80"<<endl;
    mytree.findSumPath(mytree.root,80,buffer);
    
    map<int,int> m;
    
    int hd = -1;
    cout<<"now find the vertical sum of this tree"<<endl;
    mytree.vertSum(mytree.root,hd,m);
    
    return 0;
}