#ifndef BST_H
#define BST_H
#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <map>
using namespace std;
#define nil NULL

template < typename Value >
class BST {
    
    class Node { 
        public:
            Node* left;
            Node* right;
            Value value;
            bool visited;
            bool selected;
            list<int> mylist;
        
            Node( const Value v )
            {
                value = v;
                left = nil;
                right = nil;
                visited = false;
                selected = false;
            }
            
            Value& content() { return value; }
            bool isInternal() { return left != nil && right != nil; }
            bool isExternal() { return left != nil || right != nil; }
            bool isLeaf() { return left == nil && right == nil; }
            
           int height(Node* n) {
               int h = 0;
               if(n){
                    if(n->left||n->right){
                        int lh = 0,rh = 0;
                            if(n->left){
                                lh = height(n->left);
                            }
                            if(n->right){
                                rh = height(n->right);
                            }
                            if(lh>rh)
                            h = lh + 1;
                            else
                            h = rh + 1;
                        }
                    }
                return h;
            }
    };
    
    public:
        Node* root;
        int count;

    public:
        int size(){ return size(root)-1; }
            
        int size(Node* n) {
                if(n!=NULL){
                    return size(n->left) + size(n->right);
                }
                else{
                    return 1;
                }
            }
        
        
        
        void print_node( const Node* n ) {
            cout<< n->value <<endl;
        }
        
        
        bool search ( Value x ) {
            bool bl = false;
            bool* pbl = &bl;
            search(root,x,pbl);
            return bl;
        }
        
        void search(Node* n, Value x, bool* bl){
            if(n!=NULL){
                if(n->value==x)
                    *bl = true;
                else if(x>n->value)
                    search(n->right, x, bl);
                else 
                    search(n->left, x, bl);
            }
        }
        
        void preorder()const{
            preorder(root);
        }
        void preorder(Node* n)const{
            if ( n!=NULL ) {
                cout << n->value <<" ";

                preorder(n->left);

                preorder(n->right);

            }
        }
        
        void postorder()const{postorder(root);}
        
        void postorder(Node* n)const {
            if ( n!=NULL ) {
                 postorder(n->left);
                 postorder(n->right);
                 cout << n->value <<" ";
            }
        }
        
        void inorder()const {
            inorder(root);
        }
        
        void inorder(Node* n)const{
            if ( n ) {
                inorder(n->left);
                cout << n->value << " ";
                inorder(n->right);
            }
        }
        
        
        Value& operator[] (int n) {
            
            if((n>this->size())||(n<1)||(root==NULL)){
                cout<<"index out of range ! exiting main function!!"<<endl;
                exit (EXIT_FAILURE);
            }
            
            Value& v = root->value;
            GoThrough(root,n,v);
            return v;
        }
        
        void GoThrough(Node* n, int max, Value& v){
            static int count = 0;
            if(count!=max&&n!=NULL)
            {
                v = n->value; count++;
                GoThrough(n->left, max, v);
                GoThrough(n->right, max, v);
            }
        }
        
        
        BST(){
            count = 0;
            root = NULL;
        }
        
        void insert( Value X ) { root = insert( X, root ); }
        
        Node* insert( Value X, Node* T ) {
            
            if ( T == nil ) {
                T = new Node( X ); 
            } 
            else if ( X < T->value ) {
                T->left = insert( X, T->left );
            } 
            else if ( X > T->value ) {
                T->right = insert( X, T->right );
            } 
            else {
                T->value = X;
            }
            
            int balance = getBalance(T);
            
            if(balance > 1&&X<T->left->value)
                return rightRotate(T);
                
            if(balance <-1&&X>T->right->value)
                return leftRotate(T);
                
            if(balance > 1&&X>T->left->value){
                T->left = leftRotate(T->left);
                return rightRotate(T);
            }
                
            if(balance < -1&&X<T->right->value){
                T->right = rightRotate(T->right);
                return leftRotate(T);
            }

            return T;
        }
        
        void remove( Value X ) { root = remove( X, root ); }
        
        Node* remove( Value X, Node*& T ) {
           
            if ( T != nil ) {
                if ( X > T->value ) {
                    T->right = remove( X, T->right );
                } 
                else if ( X < T->value ) {
                    T->left = remove( X, T->left );
                } 
                else { 
            
                    if ( T->right != nil ) {
                        Node* x = T->right;
                        while ( x->left != nil ) x = x->left;
                            T->value = x->value; 
                            T->right = remove( T->value, T->right );
                    } 
                    else if ( T->left != nil ) {
                        Node* x = T->left;
                        while ( x->right != nil ) x = x->right;
                        T->value = x->value; 
                        T->left = remove( T->value, T->left );
                    } 
                    else { 
                        delete T;
                        T = nil; 
                    }
                }
            }
        
            int balance = getBalance(T);
            
            if(balance > 1&&getBalance(T->left)>=0)
                return rightRotate(T);
                
            if(balance >1&&getBalance(T->left)<0)
            {
                root->left = leftRotate(T->left);
                return rightRotate(T);
            }
                
            if(balance < -1&&getBalance(T->right)<=0){
                return leftRotate(T);
            }
                
            if(balance < -1&&getBalance(T->right)>0){
                T->right = rightRotate(T->right);
                return leftRotate(T);
            }
            return T;
        }
        
    int getBalance( Node* n){
        if(n==NULL)
            return 0;
        if(n->right==NULL&&n->left!=NULL)
            return n->height(n->left) - n->height(n->right) + 1;
        if(n->right!=NULL&&n->left==NULL)
            return n->height(n->left) - n->height(n->right) - 1;
        else   
            return n->height(n->left) - n->height(n->right);
    }
    
    Node* rightRotate(Node* y){
        Node* x = y->left;
        Node* T2 = x->right;
        x->right = y;
        y->left = T2;
        return x;
    }
    
    Node* leftRotate(Node* x){
        Node* y = x->right;
        Node* T2 = y->left;
        y->left = x;
        x->right = T2;
        return y;
    }
        
    void okay( ) { okay( root ); }
    
    void okay( Node* T ) {
        
        return;
    }
    
    void minCover(){
       cout<<endl<<minCover(root);
    }
    
    int minCover(Node* n){
        static int count = 0;
            if ( n!=NULL ) {
                 count = count + DFS(n);
                 minCover(n->left);
                 minCover(n->right);
                
            }
        return count;
    }
    
    int DFS(Node* x){
        x->visited = true;
        Node* y;
        
        y = x->left;
        if(y!=NULL){
            if(y->visited==false) {
                /* if child is not selected as a vertex for minimum selected cover then
                select the parent */
                if(y->selected==false) {
                        x->selected=true;
                }
            }
       }
       
       y = x->right;
        if(y!=NULL){
            if(y->visited==false) {
                /* if child is not selected as a vertex for minimum selected cover then
                select the parent */
                if(y->selected==false) {
                        x->selected=true;
                }
            }
       }
       
       if((x==root->right||x==root->left)&&(x->right==NULL&&x->left==NULL)){
           x->selected=true;
       }
       
       if((x->selected==true)&&(x!=root)){
                     cout<<x->value<<" ";
                     return 1;
                 }
                 else{
                     return 0;
                 }
       
    }
     void findSumPath(Node* n, int sum, int buffer[]){
            static int count = 0;
            if ( n!=NULL ) {
                //cout << n->value <<" "<<count<<endl;
                buffer[count] = n->value;
                
                if ((n->right==NULL)&&(n->left==NULL) ){
                    int temp = 0;
                    for(int i = 0; i<=count; i++){
                        temp = temp + buffer[i];
                    }
                    if(temp==sum){
                        for(int i = 0; i<=count; i++){
                            cout<<buffer[i]<<" ";
                        }
                        cout<<endl;
                    }
                }
                
                count++;
                
                findSumPath(n->left,sum,buffer);
                
                findSumPath(n->right,sum,buffer);
                count--;
            }

     }
     
      void vertSum(Node* node, int hd, std::map<int, int>& m) {
          hd = 0;
          map<int,int>::iterator itr;
          collectSum(node,hd,m);
          for(itr=m.begin();itr!=m.end();itr++){
              cout<<itr->second<<" ";
          }
          cout<<endl;
      }
     
      void collectSum(Node* n, int hd, std::map<int, int>& m) {
          static int count = hd;
            if ( n!=NULL ) {
                //cout << n->value <<" "<<count<<endl;
                m[count] = m[count] + (n->value);
                
                count--;
                collectSum(n->left, hd, m);
                count++;
                
                count++;
                collectSum(n->right, hd, m);
                count--;
               //count--;
            }
      }
    
}; 
#endif