#include<iostream>
#include<stack>
#include<list>
#include"lab3.h"
using namespace std;

int main(){
  
    TwoStackFixed<int> p(10,6);
    p.pushStack2(87);
    p.pushStack2(92);
    p.pushStack2(100);
    
    p.pushStack1(80);
    p.pushStack1(300);
    p.pushStack1(300);
    p.pushStack1(300);
    
    cout<<"student name: yunjian zhang"<<endl;
    cout<<"SID: 861142074"<<endl;
    
    cout<<"part1, let's test TwoStackFixed"<<endl;
    cout<<"the arry which consists two stacks are shown below"<<endl;
    for(int i=0; i<10; i++){
      cout<<p.pointer[i]<<" ";
    }
    cout<<endl;
    cout<<"The current size of Stack 1 is "<<p.Stack_1_size<<endl;
    cout<<"The current size of Stack 2 is "<<p.Stack_2_size<<endl;
    
    cout<<"pop "<<p.popStack1()<<" from Stack1"<<endl;
    cout<<"pop "<<p.popStack2()<<" from Stack2"<<endl;
    
    cout<<"the arry which consists two stacks are shown below"<<endl;
    for(int i=0; i<10; i++){
      cout<<p.pointer[i]<<" ";
    }
    cout<<endl;
    cout<<"The current size of Stack 1 is "<<p.Stack_1_size<<endl;
    cout<<"The current size of Stack 2 is "<<p.Stack_2_size<<endl;
    cout<<endl;
    
    
    cout<<"part2, let's test TwoStackOptimal"<<endl;
    
    TwoStackOptimal<int> op(10);
    
    op.pushFlexStack1(100);
    op.pushFlexStack2(200);
    op.pushFlexStack2(150);
    op.pushFlexStack1(50);
    
    cout<<"the arry which consists two stacks are shown below"<<endl;
    for(list<int>::iterator itr = op.mylist.begin(); itr!=op.mylist.end(); itr++){
      cout<<*itr<<" ";
    }
    cout<<endl;
    
    cout<<"let's pop from Stack1 "<<op.popStack1()<<endl;
    //op.pushFlexStack1(20);
    cout<<"let's pop from Stack2 "<<op.popStack2()<<endl;
    
    cout<<"the modified arry which consists two stacks are shown below"<<endl;
    for(list<int>::iterator itr = op.mylist.begin(); itr!=op.mylist.end(); itr++){
      cout<<*itr<<" ";
    }
    cout<<endl;
    
    cout<<"the top of stack1 is "<<*(op.st1_itr)<<endl;
    cout<<"the top of stack2 is "<<*(op.st2_itr)<<endl;
    
    cout<<endl;
    
    
    
    cout<<"part3, let's play hannoi tower!! "<<endl;
    
    stack<int> A, B, C;
    
    for(int i=1; i<7; i++)
    A.push(i);
    
    
    hannoi(6,A,B,C); 
    
    
    return 0;
}