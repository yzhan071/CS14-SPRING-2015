#include <iostream>
#include <list>
#include <stack>
using namespace std;

template<typename T>
class TwoStackOptimal{
    public:
        TwoStackOptimal(int size);
        ~TwoStackOptimal();
        void pushFlexStack1(T value);
        void pushFlexStack2(T value);
        T popStack1();
        T popStack2();
        bool isFullStack1();
        bool isFullStack2();
        bool isEmptyStack1();
        bool isEmptyStack2();
    public:
        list<T> mylist;
        int current_size;
        int max_size;
        typename list<T>::iterator st1_itr;
        typename list<T>::iterator st2_itr;
        bool st1_isEnd;
        bool st2_isEnd;
};

template<typename T>
TwoStackOptimal<T>::TwoStackOptimal(int size){
    max_size = size;
    current_size = 0;
    st1_isEnd = true;
    st2_isEnd = true;
}

template<typename T>
TwoStackOptimal<T>::~TwoStackOptimal(){
    max_size = 0;
    current_size = 0;
}

template<typename T>
void TwoStackOptimal<T>::pushFlexStack1(T value){
    if(current_size>=max_size)
    {
        cout<<"stack1 overflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    else{
        current_size++;
        if(mylist.empty()){
            mylist.push_front(value);
            st1_itr = mylist.begin();
            st1_isEnd = false;
        }
        else if( (st1_isEnd==false)&&(st2_isEnd==false) )
        {
            mylist.insert(st2_itr, value);
            st1_itr++;
        }
        else if( (st1_isEnd==false)&&(st2_isEnd==true) )
        {
            mylist.push_back(value);
            st1_itr = mylist.end();
            st1_itr--;
        }
        else if( (st1_isEnd==true)&&(st2_isEnd==false) )
        {
            mylist.push_front(value);
            st1_itr = mylist.begin();
            st1_isEnd=false;
        }
        current_size++;
    }
}

template<typename T>
void TwoStackOptimal<T>::pushFlexStack2(T value){
    if(current_size>=max_size)
    {
        cout<<"stack2 overflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    else{
        current_size++;
        if(mylist.empty()){
            mylist.push_back(value);
            st2_itr = mylist.begin();
            st2_isEnd = false;
        }
        else if( (st1_isEnd==false)&&(st2_isEnd==false) )
        {
            mylist.insert(st2_itr,value);
            st2_itr--;
        }
        else if( (st1_isEnd==false)&&(st2_isEnd==true) )
        {
            mylist.push_back(value);
            st2_itr = mylist.end();
            st2_itr--;
            st2_isEnd = false;
            
        }
        else if( (st1_isEnd==true)&&(st2_isEnd==false) )
        {
            mylist.push_front(value);
            st2_itr=mylist.begin();
        }
        current_size++;
    }
}

template<typename T>
T TwoStackOptimal<T>::popStack1(){
    T temp;
    if(st1_isEnd==true)
    {
        cout<<"stack1 underflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
   else if((st1_isEnd==false)&&(st2_isEnd==false))
   {
       if(st1_itr==mylist.begin())
       {
            temp = mylist.front();
            mylist.pop_front();
            st1_isEnd = true;
       }
       else{
           temp = *st1_itr;
           st1_itr = mylist.erase(st1_itr);
           st1_itr--;
       }
       current_size--;
   }
   else if( (st1_isEnd==false)&&(st2_isEnd==true) )
   {
       
       if(st1_itr==mylist.begin())
       {
            temp = mylist.front();
            mylist.pop_front();
            st1_isEnd = true;
       }
       else{
            st1_itr--;
            temp = mylist.back();
            mylist.pop_back();
           }
       current_size--;
   }
   return temp;
}

template<typename T>
T TwoStackOptimal<T>::popStack2(){
    T temp;
    if(st2_isEnd==true)
    {
        cout<<"stack2 underflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
   else if((st1_isEnd==false)&&(st2_isEnd==false))
   {
       typename list<T>::iterator itr_temp = st2_itr;
       itr_temp++;
       if(itr_temp==mylist.end())
       {
            temp = mylist.back();
            mylist.pop_back();
            st2_isEnd = true;
       }
       else{
           temp = *st2_itr;
           st2_itr = mylist.erase(st2_itr);
       }
       current_size--;
   }
   else if( (st2_isEnd==false)&&(st1_isEnd==true) )
   {
       typename list<T>::iterator itr_temp = st2_itr;
       itr_temp++;
       if(itr_temp==mylist.end())
       {
            temp = mylist.back();
            mylist.pop_back();
            st2_isEnd = true;
       }
       else{
            st2_itr++;
            temp = mylist.front();
            mylist.pop_front();
           }
       current_size--;
   }
   return temp;
}

template<typename T>
bool TwoStackOptimal<T>::isFullStack1(){
    if(max_size == current_size)
        return true;
    else
        return false;
}

template<typename T>
bool TwoStackOptimal<T>::isFullStack2(){
    if(max_size == current_size)
        return true;
    else
        return false;
}

template<typename T>
bool TwoStackOptimal<T>::isEmptyStack1(){
    if(st1_isEnd)
        return true;
    else
        return false;
}

template<typename T>
bool TwoStackOptimal<T>::isEmptyStack2(){
    if(st2_isEnd)
        return true;
    else
        return false;
}

 
 
 
template<typename T>
class TwoStackFixed{
    public:
        TwoStackFixed(int size, int maxtop);
        ~TwoStackFixed();
        void pushStack1(T value);
        void pushStack2(T value);
        T popStack1();
        T popStack2();
        bool isEmptyStack1();
        bool isEmptyStack2();
    public:
        T *pointer;
        int Stack_1_length;
        int Stack_2_length;
        int Stack_1_size;
        int Stack_2_size;
};

template<typename T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop){
    
    if( (maxtop>size)||(maxtop<0)||(size<0) ){
        cout<<"wrong input!"<<endl<<"a default version is created !"<<endl;
        pointer = new T[100];
        Stack_2_length = 50;
        Stack_1_length = 50;
        Stack_1_size = 0;
        Stack_2_size = 0;
    }
        
    else{
        pointer = new T[size];    
        Stack_2_length = maxtop;
        Stack_1_length = size - maxtop;
        Stack_1_size = 0;
        Stack_2_size = 0;
    }
}

template<typename T>
TwoStackFixed<T>::~TwoStackFixed(){
    delete [] pointer;
    pointer = NULL;
}

template<typename T>
void TwoStackFixed<T>::pushStack1(T value)
{
    if(Stack_1_size>=Stack_1_length)
    {
        cout<<"stack1 overflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    pointer[Stack_1_size] = value;
    Stack_1_size = Stack_1_size + 1;
}

template<typename T>
void TwoStackFixed<T>::pushStack2(T value)
{
    if(Stack_2_size>=Stack_2_length)
    {
        cout<<"stack2 overflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    pointer[Stack_2_length + Stack_1_length - ( Stack_2_size + 1)] = value;
    Stack_2_size = Stack_2_size + 1;
}

template<typename T>
T TwoStackFixed<T>::popStack1(){
    T temp;
    if(Stack_1_size==0)
    {
        cout<<"stack1 underflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    else{
        temp = pointer[Stack_1_size-1];
        pointer[Stack_1_size-1] = 0;
        Stack_1_size--;
        return temp;
    }
}

template<typename T>
T TwoStackFixed<T>::popStack2(){
    T temp;
    if(Stack_2_size==0)
    {
        cout<<"stack2 underflow!! exiting main function!!"<<endl;
        exit (EXIT_FAILURE);
    }
    else{
        temp = pointer[Stack_2_length + Stack_1_length -  Stack_2_size];
        pointer[Stack_2_length + Stack_1_length -  Stack_2_size] = 0;
        Stack_2_size--;
        return temp;
    }
}

template<typename T>
bool TwoStackFixed<T>::isEmptyStack1(){
    if(Stack_1_size==0)
        return true;
    else return false;
}

template<typename T>
bool TwoStackFixed<T>::isEmptyStack2(){
    if(Stack_2_size==0)
        return true;
    else return false;
}
 
 
template<typename T>
void hannoi(int n, stack<T>& A, stack<T>& B, stack<T>& C,char from, char buffer, char to)
{
    
        if(n==1)
        {
            cout<<"Move "<<A.top()<<" from "<<from<<" to "<<to<<endl;
            C.push(A.top()); A.pop();
        }
        else{
            hannoi(n-1, A, C, B, from, to, buffer);
        
            cout<<"Move "<<A.top()<<" from "<<from<<" to "<<to<<endl;
            C.push(A.top()); A.pop();

        
            hannoi(n-1, B, A, C, buffer, from, to);
         }
} 
 
template<typename T>   
void hannoi(int n, stack<T>& A, stack<T>& B, stack<T>& C)
{
    hannoi(n, A, B, C,'A','B','C');
}